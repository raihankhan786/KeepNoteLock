package com.example.keepnotelock;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class NoteStore {
    private static final String PREF = "notes_store";
    private static final String KEY = "notes";
    public static class Note {
        public final int id;
        public final String text;
        public Note(int id, String text) { this.id = id; this.text = text; }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized List<Note> get(Context c) {
        List<Note> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i=0; i<a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Note(o.getInt("id"), o.getString("text")));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static synchronized void add(Context c, String text) {
        List<Note> notes = get(c);
        int id = (int)(System.currentTimeMillis() & 0x7fffffff);
        notes.add(new Note(id, text));
        save(c, notes);
    }

    public static synchronized void delete(Context c, int id) {
        List<Note> notes = get(c);
        List<Note> kept = new ArrayList<>();
        for (Note n : notes) if (n.id != id) kept.add(n);
        save(c, kept);
    }

    private static void save(Context c, List<Note> notes) {
        JSONArray a = new JSONArray();
        try {
            for (Note n : notes) {
                JSONObject o = new JSONObject();
                o.put("id", n.id);
                o.put("text", n.text);
                a.put(o);
            }
        } catch (Exception ignored) {}
        prefs(c).edit().putString(KEY, a.toString()).apply();
    }
}
