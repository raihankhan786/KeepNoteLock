package com.example.keepnotelock;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class NoteNotifications {
    private static final String CHANNEL = "keep_notes";
    public static void refresh(Context c) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Keep notes",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Persistent reminders saved in KeepNote Lock");
            nm.createNotificationChannel(ch);
        }

        for (NoteStore.Note n : NoteStore.get(c)) {
            Intent open = new Intent(c, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, n.id, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(c, CHANNEL)
                    : new Notification.Builder(c);
            Notification notification = b
                    .setSmallIcon(android.R.drawable.ic_menu_edit)
                    .setContentTitle("KeepNote Lock")
                    .setContentText(n.text)
                    .setStyle(new Notification.BigTextStyle().bigText(n.text))
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .build();
            notification.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
            nm.notify(n.id, notification);
        }

        // Cancel notifications for notes that have been deleted in the app.
        // App refreshes the complete set after every add/delete.
        java.util.HashSet<Integer> active = new java.util.HashSet<>();
        for (NoteStore.Note n : NoteStore.get(c)) active.add(n.id);
        for (android.service.notification.StatusBarNotification s : nm.getActiveNotifications()) {
            if (s.getId() > 0 && !active.contains(s.getId())) nm.cancel(s.getId());
        }
    }
}
