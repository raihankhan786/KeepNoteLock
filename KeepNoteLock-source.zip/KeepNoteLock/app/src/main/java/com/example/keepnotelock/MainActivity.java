package com.example.keepnotelock;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout list;
    private EditText editor;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        buildUi();
        NoteNotifications.refresh(this);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 100) NoteNotifications.refresh(this);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(36, 40, 36, 32);
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("KeepNote Lock");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Your notes stay in notifications until you delete them here.");
        sub.setTextSize(14);
        sub.setPadding(0, 8, 0, 22);
        page.addView(sub);

        editor = new EditText(this);
        editor.setHint("Write a reminder...");
        editor.setMinLines(2);
        editor.setGravity(48);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        page.addView(editor);

        Button add = new Button(this);
        add.setText("Add note");
        page.addView(add);
        add.setOnClickListener(v -> {
            String text = editor.getText().toString().trim();
            if (!text.isEmpty()) {
                NoteStore.add(this, text);
                editor.setText("");
                NoteNotifications.refresh(this);
                renderNotes();
            }
        });

        TextView heading = new TextView(this);
        heading.setText("Saved notes");
        heading.setTextSize(19);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setPadding(0, 28, 0, 10);
        page.addView(heading);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        setContentView(scroll);
        renderNotes();
    }

    private void renderNotes() {
        list.removeAllViews();
        List<NoteStore.Note> notes = NoteStore.get(this);
        if (notes.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No notes yet.");
            list.addView(empty);
        }
        for (NoteStore.Note n : notes) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(18, 16, 18, 16);
            row.setBackgroundColor(0xFFF1F3F5);

            TextView text = new TextView(this);
            text.setText(n.text);
            text.setTextSize(16);
            row.addView(text);

            Button delete = new Button(this);
            delete.setText("Delete from app");
            row.addView(delete);
            delete.setOnClickListener(v -> {
                NoteStore.delete(this, n.id);
                android.app.NotificationManager nm =
                    (android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                nm.cancel(n.id);
                NoteNotifications.refresh(this);
                renderNotes();
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = 14;
            list.addView(row, lp);
        }
    }
}
