# KeepNote Lock

A small native Android notes app that posts one ongoing notification per saved note.

## Build on GitHub (phone-friendly)
1. Create a **public** GitHub repository named `KeepNoteLock`.
2. Upload all files and folders from this project ZIP to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build KeepNote Lock APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `KeepNote-Lock-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Important Android behavior
The app requests notification permission on Android 13+. Notifications are marked ongoing and no-clear and contain no action buttons. Android/system behavior can still vary by OS version and manufacturer. Test Clear All and individual swipe dismissal on your phone.

## Privacy
Notes are stored locally in the app's SharedPreferences. The project does not include analytics, ads, accounts, or network calls.
